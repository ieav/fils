# new_note
## 这是一个新的笔记
### 字体
*斜体*
**加粗**
<mark>高亮==</mark>
~~横线~~
/<*im*g:
**src**
~~sdklsdf~~


、、、就乐山大佛
<font color=red>$$@@@颜色文本处理</font>
<font color=blue>$$@@@颜色文本处理</font>
~~sjdfkl~~
`sjdfl sddfjsldf`
<mark>$$@@ mark 标签</mark>
[腾讯视频](v.qq.com)
<font face="黑体">黑体</font>
<font face="微软雅黑">微软雅黑</font>
### 代码块
```java
<!-- 注释信息   在 实际中不显示 出来  这个应该是放在代码块里面的。-->
public static void main(String args){
        System.Out.println("hello world!");
}
```
```cpp 
    <!-- 这里是注释信息 -->
    code
  @@
```
### 链接
[插入一个 **百度** 链接试试](www.baidu.com)

![这里是名字嘛timg (1)](_v_images/20201013143637480_4036.jpg =168x)

### 表格
| sdjklf      | jksdf        |
| :---------- | :----------- |
| 原来还可以写 | 这里就是结果了 |
| 你也可以的  | 就这样就了     |

#### 中间表格
| sdf | sdf |
| :-: | :-: |
|  s  |  s  |
|  s  |  s  |

### 查看幻词
this day is 20201013  

20201013 
%help%
```  ''' 快捷键：  Ctr+E M  '''
       配置幻词： 在配置文件夹中编辑 vnote.ini 文件
      %hw% + 快捷键 先按ctrl+e 再按m --> hello world!
       vnote is a great tool! -- Written 2020-10-16 16:43:16

```
### 模板
 VNote支持基于模板创建笔记。
 ![v_images](_v_images/20201016165021977_963.png =648x)
### 主题和风格 && Vnote 其他功能 链接
([主体和风格配置](https://vnote.readthedocs.io/zh_CN/latest/user_docs/themes_and_styles.html))
   还有 --
              -- 导出world pdf html 等功能介绍
              -- 小推车功能
              -- 全文搜索功能使用
              -- 其他额外功能
([如何指定自定义的MathJax脚本？](https://vnote.readthedocs.io/zh_CN/latest/user_docs/faqs.html#how-to-specify-customized-mathjax-script))
([如何让VNote更「便携」？](https://vnote.readthedocs.io/zh_CN/latest/user_docs/faqs.html#how-to-make-vnote-more-portable))
([如何使用Mermaid或Flowchart.js绘制图表？](https://vnote.readthedocs.io/zh_CN/latest/user_docs/faqs.html#how-to-draw-diagrams-using-mermaid-or-flowchart-js))
([如何在另一个标签中打开笔记？](https://vnote.readthedocs.io/zh_CN/latest/user_docs/faqs.html#how-to-open-a-note-in-another-tab))
([界面无响应](https://vnote.readthedocs.io/zh_CN/latest/user_docs/faqs.html#interface-is-freezed))
([编辑模式中没有光标](https://vnote.readthedocs.io/zh_CN/latest/user_docs/faqs.html#cursor-is-not-visible-in-edit-mode))
([打开一个笔记后软件异常退出](https://vnote.readthedocs.io/zh_CN/latest/user_docs/faqs.html#crash-when-opening-a-note))
([全屏模式中菜单无法正常显示](https://vnote.readthedocs.io/zh_CN/latest/user_docs/faqs.html#menu-does-not-work-in-fullscreen-mode))

###分割线
***
---
<hr/>
>>> ‘<hr/>会影响 后面的横线’

///////

### 已完成 未完成
   - [ ] 未完成
   - [x]   已完成
   
### 注脚 && 标记符号
   [^1]  注解 
  
  : djfld

  = 等号标记
  = 等号标记
   -  减号标记
   - 减号
   * 星号标记
   * 星号
   * 编辑偶
   
### 引用
>怎么引用的东西
>一级引用
>`行内代码`
>```  <!--注释 -->
>protected void onCreate(Bundle savedInstanceState) {
>   super.onCreate(savedInstanceState);
>   setContentView(R.layout.activity_main);
>}
>```

>>二级引用
>>jlsdj

>>>三级引用

---
在行尾添加两个空格加回车表示换行：（vnote 换行没用）
jklsdf    换行

这是一个脚注的例子[^1]
[^1]: 这里是脚注

### 文本对齐

----
<p align="left">居左文本</p>
<p align="center">居中文本</p>
<p align="right">居右文本</p>

### 下划线
----
<u>下划线文本</u>

###任务列表
---
- [x]Write the press release
- [ ]Update the website
- [ ]Contact the media
### 自己的其他尝试
---- 
> 在代码块里面写引用
``` 
<!--这里是代码块-->
>原来里面可以写引用
>>但是只能写一级引用----都不行
```

